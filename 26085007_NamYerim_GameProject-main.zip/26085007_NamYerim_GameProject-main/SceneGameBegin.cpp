#include "SceneGameBegin.h"

int SceneGameBegin::Init()
{
    Destroy();

    //����̹���
    m_txMain = g2_TextureLoad("Texture/Main_BG.png");
    m_txHowTo = g2_TextureLoad("Texture/Img_HowTo.png");

    //��ư �̹��� �ε�
    m_txBtnStartNormal = g2_TextureLoad("Texture/Btn_Start_Normal.png");
    m_txBtnStartHover = g2_TextureLoad("Texture/Btn_Start_Hover.png");

    m_txBtnHowToNormal = g2_TextureLoad("Texture/Btn_HowTo_Normal.png");
    m_txBtnHowToHover = g2_TextureLoad("Texture/Btn_HowTo_Hover.png");

    m_txBtnExitNormal = g2_TextureLoad("Texture/Btn_Exit_Normal.png");
    m_txBtnExitHover = g2_TextureLoad("Texture/Btn_Exit_Hover.png");

    //���� �ε�
    m_sndBgm = g2_SoundLoad("Sound/BGM_Main.wav.mp3");
    m_sndButtonClick = g2_SoundLoad("Sound/SFX_ButtonClick.wav.mp3");
    m_sndStartClick = g2_SoundLoad("Sound/SFX_StartClick.wav.mp3");

    // ���� ������� �ݺ� ���  �� �߰�
    if (m_sndBgm >= 0) g2_SoundPlay(m_sndBgm, true);

    m_showHowTo = false;
    m_prevEnter = false;
    m_prevMouse = false;

    return 0;
}

int SceneGameBegin::Destroy()
{
    if (m_txMain >= 0) 
    { 
        g2_TextureRelease(m_txMain);  
        m_txMain = -1; 
    }
    if (m_txHowTo >= 0) 
    {
        g2_TextureRelease(m_txHowTo); 
        m_txHowTo = -1; 
    }

    if (m_txBtnStartNormal >= 0) 
    { 
        g2_TextureRelease(m_txBtnStartNormal); 
        m_txBtnStartNormal = -1; 
    }
    if (m_txBtnStartHover >= 0) 
    { 
        g2_TextureRelease(m_txBtnStartHover);  
        m_txBtnStartHover = -1; 
    }

    if (m_txBtnHowToNormal >= 0) 
    { 
        g2_TextureRelease(m_txBtnHowToNormal); 
        m_txBtnHowToNormal = -1; 
    }
    if (m_txBtnHowToHover >= 0) 
    { 
        g2_TextureRelease(m_txBtnHowToHover);  
        m_txBtnHowToHover = -1; 
    }

    if (m_txBtnExitNormal >= 0) 
    { 
        g2_TextureRelease(m_txBtnExitNormal);  
        m_txBtnExitNormal = -1; 
    }

    if (m_txBtnExitHover >= 0) 
    { 
        g2_TextureRelease(m_txBtnExitHover);   
        m_txBtnExitHover = -1; 
    }
    if (m_sndBgm >= 0) 
    { 
        g2_SoundStop(m_sndBgm); 
        g2_SoundRelease(m_sndBgm); 
        m_sndBgm = -1; 
    }
    if (m_sndButtonClick >= 0) 
    { 
        g2_SoundRelease(m_sndButtonClick); 
        m_sndButtonClick = -1; 
    }
    if (m_sndStartClick >= 0) 
    { 
        g2_SoundRelease(m_sndStartClick); 
        m_sndStartClick = -1; 
    }

    return 0;
}

bool SceneGameBegin::IsKeyPressed(int key)
{
    SHORT state = GetAsyncKeyState(key);
    return (state & 0x8000) != 0;
}

bool SceneGameBegin::IsMouseClicked()
{
    bool currentMouse = IsKeyPressed(VK_LBUTTON);
    bool clicked = currentMouse && !m_prevMouse;
    m_prevMouse = currentMouse;

    return clicked;
}

int SceneGameBegin::Update(const KEYCODE* keys)
{
    bool enterPressed = IsKeyPressed(VK_RETURN);
    bool enterDown = enterPressed && !m_prevEnter;
    m_prevEnter = enterPressed;

    // ���콺 ��ǥ ���ϱ� (Ŭ���̾�Ʈ â ���� ��ǥ ����)
    POINT cursorPosition{ 0, 0 };
    GetCursorPos(&cursorPosition);

    HWND foregroundWindow = GetForegroundWindow();
    if (foregroundWindow != nullptr)
    {
        ScreenToClient(foregroundWindow, &cursorPosition);
    }

    m_mouseX = cursorPosition.x;
    m_mouseY = cursorPosition.y;

    bool mouseClicked = IsMouseClicked();

    // ���� ��� �˾� ��� �� ó��
    if (m_showHowTo)
    {
        if (mouseClicked || enterDown || IsKeyPressed(VK_ESCAPE))
        {
            m_showHowTo = false;
        }
        return 0;
    }

    /* ��ư Ŭ�� �̺�Ʈ
    if (mouseClicked)
    {
        if (m_btnStart.Contains(m_mouseX, m_mouseY))
        {
            return 1; // ���� ����
        }

        if (m_btnHowTo.Contains(m_mouseX, m_mouseY))
        {
            m_showHowTo = true;
            return 0;
        }

        if (m_btnExit.Contains(m_mouseX, m_mouseY))
        {
            return -1; // ���� ����
        }
    }*/
    
    // ��ư Ŭ�� �̺�Ʈ
    if (mouseClicked)
    {
        if (m_btnStart.Contains(m_mouseX, m_mouseY))
        {
            if (m_sndBgm >= 0) 
                g2_SoundStop(m_sndBgm);        // ���� BGM ����
            if (m_sndStartClick >= 0) 
                g2_SoundPlay(m_sndStartClick);
            return 1; // ���� ����
        }

        if (m_btnHowTo.Contains(m_mouseX, m_mouseY))
        {
            if (m_sndButtonClick >= 0) 
                g2_SoundPlay(m_sndButtonClick);
            m_showHowTo = true;
            return 0;
        }

        if (m_btnExit.Contains(m_mouseX, m_mouseY))
        {
            if (m_sndBgm >= 0) 
                g2_SoundStop(m_sndBgm);
            return -1; // ���� ����
        }
    }

    return 0;
}

int SceneGameBegin::Render()
{
    g2_DrawAlphaOption(255);

    // ���� ��� �̹��� ���
    if (m_txMain >= 0)
    {
        g2_Draw2D(m_txMain, nullptr);
    }

    // ��ư �ؽ�ó ��� (�˾�â�� ���� ���� ���� ����)
    if (!m_showHowTo)
    {
        // [���� ����] ��ư
        bool isStartHover = m_btnStart.Contains(m_mouseX, m_mouseY);
        int txStart = isStartHover ? m_txBtnStartHover : m_txBtnStartNormal;
        if (txStart >= 0)
        {
            g2_Draw2D(txStart, nullptr); 
        }

        // [���� ���] ��
        bool isHowToHover = m_btnHowTo.Contains(m_mouseX, m_mouseY);
        int txHowTo = isHowToHover ? m_txBtnHowToHover : m_txBtnHowToNormal;
        if (txHowTo >= 0)
        {
            g2_Draw2D(txHowTo, nullptr);
        }

        // [�� �� ��] ��ư 
        bool isExitHover = m_btnExit.Contains(m_mouseX, m_mouseY);
        int txExit = isExitHover ? m_txBtnExitHover : m_txBtnExitNormal;
        if (txExit >= 0)
        {
            g2_Draw2D(txExit, nullptr);
        }
    }

    // ���� ��� �˾�â ���
    if (m_showHowTo && m_txHowTo >= 0)
    {
        g2_Draw2D(m_txHowTo, nullptr);
    }

    return 0;
}

